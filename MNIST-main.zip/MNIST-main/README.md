# MNIST
First deep learning project, using the MNIST dataset and PyTorch
